"use client"

import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowRight, Info } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

const decisionsFormSchema = z.object({
  lifeSustainingTreatment: z.enum(["yes", "no"], {
    required_error: "Please select whether your attorneys can make decisions about life-sustaining treatment",
  }),
  preferences: z.string().optional(),
  instructions: z.string().optional(),
  financialDecisions: z.object({
    manageBankAccounts: z.boolean().optional(),
    buyOrSellProperty: z.boolean().optional(),
    makeLimitedGifts: z.boolean().optional(),
    payForCare: z.boolean().optional(),
    investAssets: z.boolean().optional(),
    payBills: z.boolean().optional(),
    dealWithTaxes: z.boolean().optional(),
  }),
})

type DecisionsForm = z.infer<typeof decisionsFormSchema>

export default function DecisionsPage({ params }: { params: { type: string } }) {
  const router = useRouter()
  const isHealthLPA = params.type === "health-and-welfare" || params.type === "both"
  const isPropertyLPA = params.type === "property-and-financial" || params.type === "both"

  const form = useForm<DecisionsForm>({
    resolver: zodResolver(decisionsFormSchema),
    defaultValues: {
      preferences: "",
      instructions: "",
      financialDecisions: {
        manageBankAccounts: false,
        buyOrSellProperty: false,
        makeLimitedGifts: false,
        payForCare: false,
        investAssets: false,
        payBills: false,
        dealWithTaxes: false,
      },
    },
  })

  function onSubmit(data: DecisionsForm) {
    // In a real application, you would save this data to your backend
    console.log(data)
    router.push(`/lpa/${params.type}/people-to-notify`)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Decisions and Preferences</h1>
        <p className="mt-2 text-gray-600">Specify how you want your attorneys to make decisions on your behalf</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {isHealthLPA && (
            <Card>
              <CardHeader>
                <CardTitle>Life-Sustaining Treatment</CardTitle>
                <CardDescription>
                  Decide whether your attorneys can give or refuse consent to life-sustaining treatment on your behalf
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Alert className="mb-6">
                  <Info className="h-4 w-4" />
                  <AlertTitle>Important</AlertTitle>
                  <AlertDescription>
                    Life-sustaining treatment means care, surgery, medicine or other help from doctors that's needed to
                    keep you alive, for example: a serious operation, such as a heart bypass or organ transplant; cancer
                    treatment; artificial nutrition or hydration (food or water given other than by mouth).
                  </AlertDescription>
                </Alert>

                <FormField
                  control={form.control}
                  name="lifeSustainingTreatment"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel>
                        Do you want to give your attorneys authority to give or refuse consent to life-sustaining
                        treatment on your behalf?
                      </FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-col space-y-1"
                        >
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="yes" />
                            </FormControl>
                            <FormLabel className="font-normal">
                              Yes - I want my attorneys to make these decisions
                            </FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="no" />
                            </FormControl>
                            <FormLabel className="font-normal">
                              No - I want my doctors to make these decisions
                            </FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          )}

          {isPropertyLPA && (
            <Card>
              <CardHeader>
                <CardTitle>Financial Decisions</CardTitle>
                <CardDescription>
                  Select the types of financial decisions your attorneys can make on your behalf
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  <FormField
                    control={form.control}
                    name="financialDecisions.manageBankAccounts"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Manage bank and building society accounts</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="financialDecisions.buyOrSellProperty"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Buy or sell property (including your home)</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="financialDecisions.makeLimitedGifts"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Make limited gifts of money</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="financialDecisions.payForCare"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Pay for private medical care, residential care or nursing home fees</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="financialDecisions.investAssets"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Invest your savings or other assets</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="financialDecisions.payBills"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Pay your bills</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="financialDecisions.dealWithTaxes"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Deal with tax affairs</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Preferences and Instructions</CardTitle>
              <CardDescription>
                You can add preferences (what you'd like) and instructions (what your attorneys must do)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <FormField
                  control={form.control}
                  name="preferences"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Preferences (optional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter any preferences you have for how your attorneys should act"
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        These are things you'd like your attorneys to think about when making decisions for you, but
                        they don't have to follow them.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="instructions"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Instructions (optional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter any specific instructions for your attorneys"
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        These are things that your attorneys must do when making decisions on your behalf.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-between">
            <Button type="button" variant="outline" onClick={() => router.push(`/lpa/${params.type}/attorneys`)}>
              Previous
            </Button>
            <Button type="submit">
              Continue
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </form>
      </Form>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-medium text-blue-800">Guidance on Preferences and Instructions</h3>
        <div className="mt-2 text-sm text-blue-700">
          <p className="mb-2">
            <strong>Preferences</strong> are what you'd like your attorneys to consider when making decisions:
          </p>
          <ul className="list-disc pl-4 space-y-1 mb-4">
            <li>I'd prefer to live close to my family</li>
            <li>I'd like my pets to live with me where possible</li>
            <li>I'd prefer to be cared for at home</li>
          </ul>
          <p className="mb-2">
            <strong>Instructions</strong> are things your attorneys must do:
          </p>
          <ul className="list-disc pl-4 space-y-1">
            <li>My attorneys must ensure my home is maintained until I need residential care</li>
            <li>My attorneys must consult my doctor before making major healthcare decisions</li>
            <li>My attorneys must continue making donations to the charities I currently support</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

