"use client"

import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowRight, Info, Check, CreditCard, FileText } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"

const feesFormSchema = z.object({
  applyForFeeRemission: z.boolean(),
  remissionType: z.enum(["full", "partial", "none"]).optional(),
  benefitsReceived: z.array(z.string()).optional(),
  lowIncome: z.boolean().optional(),
  financialHardship: z.boolean().optional(),
  paymentMethod: z.enum(["card", "cheque", "bank-transfer"], {
    required_error: "Please select a payment method",
  }),
})

type FeesForm = z.infer<typeof feesFormSchema>

export default function FeesPage({ params }: { params: { type: string } }) {
  const router = useRouter()

  const form = useForm<FeesForm>({
    resolver: zodResolver(feesFormSchema),
    defaultValues: {
      applyForFeeRemission: false,
      benefitsReceived: [],
      lowIncome: false,
      financialHardship: false,
      paymentMethod: "card",
    },
  })

  const applyForFeeRemission = form.watch("applyForFeeRemission")
  const remissionType = form.watch("remissionType")

  function onSubmit(data: FeesForm) {
    // In a real application, you would save this data to your backend
    console.log(data)
    router.push(`/lpa/${params.type}/review`)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">LPA Registration Fees</h1>
        <p className="mt-2 text-gray-600">There is a fee to register your LPA with the Office of the Public Guardian</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Registration Fee</CardTitle>
          <CardDescription>The fee to register an LPA is £82</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
              <div>
                <h3 className="font-medium text-gray-900">LPA Registration Fee</h3>
                <p className="text-sm text-gray-600">Office of the Public Guardian fee</p>
              </div>
              <div className="text-xl font-bold">£82</div>
            </div>

            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>About the registration fee</AlertTitle>
              <AlertDescription>
                <p>
                  This fee is paid to the Office of the Public Guardian (OPG) to process and register your LPA. You may
                  be eligible for a fee reduction or exemption based on your circumstances.
                </p>
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Fee Reduction or Exemption</CardTitle>
              <CardDescription>You may be eligible to pay a reduced fee or no fee at all</CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="applyForFeeRemission"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>I want to apply for a fee reduction or exemption</FormLabel>
                      <FormDescription>
                        You may be eligible if you receive certain benefits, have a low income, or are experiencing
                        financial hardship
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />

              {applyForFeeRemission && (
                <div className="mt-6 space-y-6">
                  <FormField
                    control={form.control}
                    name="remissionType"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>What type of fee reduction are you applying for?</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex flex-col space-y-1"
                          >
                            <FormItem className="flex items-start space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="full" />
                              </FormControl>
                              <div className="space-y-1">
                                <FormLabel className="font-medium">Full exemption (no fee)</FormLabel>
                                <FormDescription>
                                  If you receive certain means-tested benefits or have a low income
                                </FormDescription>
                              </div>
                            </FormItem>
                            <FormItem className="flex items-start space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="partial" />
                              </FormControl>
                              <div className="space-y-1">
                                <FormLabel className="font-medium">50% reduction (£41)</FormLabel>
                                <FormDescription>If your income is below a certain threshold</FormDescription>
                              </div>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {remissionType === "full" && (
                    <div className="space-y-4">
                      <FormField
                        control={form.control}
                        name="benefitsReceived"
                        render={() => (
                          <FormItem>
                            <div className="mb-4">
                              <FormLabel className="text-base">Which benefits do you receive?</FormLabel>
                              <FormDescription>Select all benefits that you currently receive</FormDescription>
                            </div>
                            <div className="grid gap-2">
                              {[
                                "Universal Credit",
                                "Income Support",
                                "Income-based Employment and Support Allowance",
                                "Income-based Jobseeker's Allowance",
                                "Guarantee Credit (part of Pension Credit)",
                                "Housing Benefit",
                                "None of these",
                              ].map((benefit) => (
                                <FormField
                                  key={benefit}
                                  control={form.control}
                                  name="benefitsReceived"
                                  render={({ field }) => {
                                    return (
                                      <FormItem key={benefit} className="flex flex-row items-start space-x-3 space-y-0">
                                        <FormControl>
                                          <Checkbox
                                            checked={field.value?.includes(benefit)}
                                            onCheckedChange={(checked) => {
                                              return checked
                                                ? field.onChange([...field.value, benefit])
                                                : field.onChange(field.value?.filter((value) => value !== benefit))
                                            }}
                                          />
                                        </FormControl>
                                        <FormLabel className="font-normal">{benefit}</FormLabel>
                                      </FormItem>
                                    )
                                  }}
                                />
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="lowIncome"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>I have a low income (less than £1,085 per month)</FormLabel>
                              <FormDescription>You'll need to provide evidence of your income</FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>
                  )}

                  {remissionType === "partial" && (
                    <FormField
                      control={form.control}
                      name="financialHardship"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>I declare that paying the full fee would cause me financial hardship</FormLabel>
                            <FormDescription>
                              You'll need to provide evidence of your financial situation
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  )}

                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertTitle>Evidence required</AlertTitle>
                    <AlertDescription>
                      You'll need to provide evidence to support your application for a fee reduction or exemption. This
                      could include benefit award letters, bank statements, or other financial documents.
                    </AlertDescription>
                  </Alert>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment Method</CardTitle>
              <CardDescription>Choose how you want to pay the registration fee</CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="paymentMethod"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-start space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="card" />
                          </FormControl>
                          <div className="space-y-1">
                            <FormLabel className="font-medium flex items-center">
                              <CreditCard className="h-4 w-4 mr-2" />
                              Credit or Debit Card
                            </FormLabel>
                            <FormDescription>Pay securely online</FormDescription>
                          </div>
                        </FormItem>
                        <FormItem className="flex items-start space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="cheque" />
                          </FormControl>
                          <div className="space-y-1">
                            <FormLabel className="font-medium">Cheque</FormLabel>
                            <FormDescription>Make payable to "Office of the Public Guardian"</FormDescription>
                          </div>
                        </FormItem>
                        <FormItem className="flex items-start space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="bank-transfer" />
                          </FormControl>
                          <div className="space-y-1">
                            <FormLabel className="font-medium">Bank Transfer</FormLabel>
                            <FormDescription>
                              We'll provide bank details after you submit your application
                            </FormDescription>
                          </div>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium text-gray-900">LPA Registration Fee</h3>
                    <p className="text-sm text-gray-600">Standard fee</p>
                  </div>
                  <div className="text-lg">£82</div>
                </div>

                {applyForFeeRemission && remissionType === "full" && (
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium text-gray-900">Fee Exemption</h3>
                      <p className="text-sm text-gray-600">Full exemption applied</p>
                    </div>
                    <div className="text-lg text-red-600">-£82</div>
                  </div>
                )}

                {applyForFeeRemission && remissionType === "partial" && (
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium text-gray-900">Fee Reduction (50%)</h3>
                      <p className="text-sm text-gray-600">Partial reduction applied</p>
                    </div>
                    <div className="text-lg text-red-600">-£41</div>
                  </div>
                )}

                <Separator />

                <div className="flex justify-between items-center font-bold">
                  <div>
                    <h3 className="text-gray-900">Total to Pay</h3>
                  </div>
                  <div className="text-xl">
                    {applyForFeeRemission && remissionType === "full"
                      ? "£0"
                      : applyForFeeRemission && remissionType === "partial"
                        ? "£41"
                        : "£82"}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 border-t">
              <div className="w-full flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-600">
                  <FileText className="h-4 w-4 mr-1" />
                  <span>Payment will be processed after review</span>
                </div>
                <div className="flex items-center text-sm text-green-600">
                  <Check className="h-4 w-4 mr-1" />
                  <span>Secure payment</span>
                </div>
              </div>
            </CardFooter>
          </Card>

          <div className="flex justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.push(`/lpa/${params.type}/certificate-provider`)}
            >
              Previous
            </Button>
            <Button type="submit">
              Continue to Review
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </form>
      </Form>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-medium text-blue-800">About Fee Reductions and Exemptions</h3>
        <div className="mt-2 text-sm text-blue-700">
          <p className="mb-2">You may be eligible for a fee reduction or exemption if:</p>
          <ul className="list-disc pl-4 space-y-1">
            <li>You receive certain means-tested benefits</li>
            <li>Your income is below £1,085 per month (before tax)</li>
            <li>You would suffer financial hardship if you paid the full fee</li>
          </ul>
          <p className="mt-2">
            You'll need to provide evidence to support your application for a fee reduction or exemption.
          </p>
        </div>
      </div>
    </div>
  )
}

