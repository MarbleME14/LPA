"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { ArrowRight, Check, FileText, User, Users, Brain, Bell, CreditCard, Download, Printer } from "lucide-react"
import { useState } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function ReviewPage({ params }: { params: { type: string } }) {
  const router = useRouter()
  const [agreed, setAgreed] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = () => {
    // In a real application, you would submit the LPA to your backend
    setSubmitted(true)
    // After submission, you would redirect to a confirmation page
    setTimeout(() => {
      router.push("/dashboard")
    }, 5000)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Review Your LPA</h1>
        <p className="mt-2 text-gray-600">
          Please review all the information you've provided before submitting your LPA
        </p>
      </div>

      {submitted ? (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <Check className="h-8 w-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">LPA Submitted Successfully</h2>
              <p className="text-gray-600 max-w-md">
                Your LPA has been submitted to the Office of the Public Guardian for processing. You will receive
                confirmation by email shortly.
              </p>
              <div className="flex space-x-4 mt-4">
                <Button variant="outline" className="flex items-center">
                  <Printer className="h-4 w-4 mr-2" />
                  Print Receipt
                </Button>
                <Button variant="outline" className="flex items-center">
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
              </div>
              <p className="text-sm text-gray-500 mt-4">Redirecting to dashboard in 5 seconds...</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2 text-blue-600" />
                LPA Type
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-medium">
                {params.type === "property-and-financial"
                  ? "Property and Financial Affairs LPA"
                  : params.type === "health-and-welfare"
                    ? "Health and Welfare LPA"
                    : "Property & Financial Affairs and Health & Welfare LPA"}
              </p>
              <p className="text-sm text-gray-600 mt-1">
                {params.type === "property-and-financial"
                  ? "For decisions about money and property"
                  : params.type === "health-and-welfare"
                    ? "For decisions about care and medical treatment"
                    : "For decisions about both money/property and care/medical treatment"}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2 text-blue-600" />
                Donor Details
              </CardTitle>
              <CardDescription>The person making the LPA</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-900">Personal Details</h3>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <p className="text-sm text-gray-500">Name</p>
                      <p>John Smith</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Date of Birth</p>
                      <p>15 January 1965</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Email</p>
                      <p>john.smith@example.com</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Phone</p>
                      <p>07700 900123</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900">Address</h3>
                  <p className="mt-2">
                    123 High Street
                    <br />
                    Anytown
                    <br />
                    London
                    <br />
                    AB12 3CD
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2 text-blue-600" />
                Attorneys
              </CardTitle>
              <CardDescription>The people you've chosen to make decisions for you</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-gray-900">Attorney 1</h3>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <p className="text-sm text-gray-500">Name</p>
                      <p>Sarah Johnson</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Relationship</p>
                      <p>Daughter</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Email</p>
                      <p>sarah.johnson@example.com</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Phone</p>
                      <p>07700 900456</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">Address</p>
                  <p>
                    45 Park Lane
                    <br />
                    Anytown
                    <br />
                    London
                    <br />
                    AB12 5EF
                  </p>
                </div>

                <Separator />

                <div>
                  <h3 className="font-medium text-gray-900">Attorney 2</h3>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <p className="text-sm text-gray-500">Name</p>
                      <p>Michael Smith</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Relationship</p>
                      <p>Son</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Email</p>
                      <p>michael.smith@example.com</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Phone</p>
                      <p>07700 900789</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">Address</p>
                  <p>
                    67 Church Road
                    <br />
                    Anytown
                    <br />
                    London
                    <br />
                    AB12 7GH
                  </p>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900">How attorneys should work together</h3>
                  <p className="mt-2">Jointly and Severally (attorneys can make decisions on their own or together)</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="h-5 w-5 mr-2 text-blue-600" />
                Decisions and Preferences
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {(params.type === "health-and-welfare" || params.type === "both") && (
                  <div>
                    <h3 className="font-medium text-gray-900">Life-Sustaining Treatment</h3>
                    <p className="mt-2">Yes - I want my attorneys to make these decisions</p>
                  </div>
                )}

                {(params.type === "property-and-financial" || params.type === "both") && (
                  <div>
                    <h3 className="font-medium text-gray-900">Financial Decisions</h3>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>Manage bank and building society accounts</li>
                      <li>Buy or sell property (including your home)</li>
                      <li>Pay for private medical care, residential care or nursing home fees</li>
                      <li>Pay your bills</li>
                    </ul>
                  </div>
                )}

                <div>
                  <h3 className="font-medium text-gray-900">Preferences</h3>
                  <p className="mt-2 italic">
                    "I'd prefer to live close to my family if I need care. I'd like my pets to live with me where
                    possible."
                  </p>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900">Instructions</h3>
                  <p className="mt-2 italic">
                    "My attorneys must ensure my home is maintained until I need residential care. My attorneys must
                    consult my doctor before making major healthcare decisions."
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="h-5 w-5 mr-2 text-blue-600" />
                People to Notify
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div>
                <h3 className="font-medium text-gray-900">Person to Notify 1</h3>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div>
                    <p className="text-sm text-gray-500">Name</p>
                    <p>Robert Williams</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Address</p>
                    <p>
                      89 Queen Street
                      <br />
                      Anytown
                      <br />
                      London
                      <br />
                      AB12 9JK
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2 text-blue-600" />
                Certificate Provider
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-900">Certificate Provider Details</h3>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <p className="text-sm text-gray-500">Name</p>
                      <p>Dr. James Wilson</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Type</p>
                      <p>Professional certificate provider</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Profession</p>
                      <p>Doctor</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Contact</p>
                      <p>james.wilson@example.com</p>
                      <p>07700 900321</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="h-5 w-5 mr-2 text-blue-600" />
                Fees and Payment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium text-gray-900">LPA Registration Fee</h3>
                    <p className="text-sm text-gray-600">Standard fee</p>
                  </div>
                  <div className="text-lg">£82</div>
                </div>

                <div className="flex justify-between items-center font-bold">
                  <div>
                    <h3 className="text-gray-900">Total to Pay</h3>
                  </div>
                  <div className="text-xl">£82</div>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900">Payment Method</h3>
                  <p className="mt-2">Credit or Debit Card</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Alert>
            <AlertTitle>Important</AlertTitle>
            <AlertDescription>
              By submitting this LPA, you confirm that all the information provided is true to the best of your
              knowledge. After submission, your LPA will be sent to the Office of the Public Guardian for registration.
            </AlertDescription>
          </Alert>

          <div className="flex items-start space-x-2">
            <Checkbox id="terms" checked={agreed} onCheckedChange={(checked) => setAgreed(!!checked)} />
            <div className="grid gap-1.5 leading-none">
              <label
                htmlFor="terms"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                I confirm that all the information I have provided is correct
              </label>
              <p className="text-sm text-gray-500">
                I understand that it is an offense to deliberately provide false information on this application
              </p>
            </div>
          </div>

          <div className="flex justify-between">
            <Button type="button" variant="outline" onClick={() => router.push(`/lpa/${params.type}/fees`)}>
              Previous
            </Button>
            <Button onClick={handleSubmit} disabled={!agreed}>
              Submit LPA
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </>
      )}
    </div>
  )
}

