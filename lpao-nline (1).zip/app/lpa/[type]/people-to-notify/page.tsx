"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useFieldArray, useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowRight, Plus, Trash2, AlertTriangle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

const personSchema = z.object({
  title: z.string({
    required_error: "Please select a title",
  }),
  firstName: z.string().min(2, {
    message: "First name must be at least 2 characters.",
  }),
  lastName: z.string().min(2, {
    message: "Last name must be at least 2 characters.",
  }),
  address: z.object({
    line1: z.string().min(1, "Address line 1 is required"),
    line2: z.string().optional(),
    town: z.string().min(1, "Town/City is required"),
    county: z.string().optional(),
    postcode: z.string().min(5, "Please enter a valid postcode"),
  }),
})

const peopleToNotifyFormSchema = z.object({
  includePeopleToNotify: z.boolean(),
  people: z.array(personSchema).optional(),
})

type PeopleToNotifyForm = z.infer<typeof peopleToNotifyFormSchema>

export default function PeopleToNotifyPage({ params }: { params: { type: string } }) {
  const router = useRouter()
  const [includePeople, setIncludePeople] = useState(false)

  const form = useForm<PeopleToNotifyForm>({
    resolver: zodResolver(peopleToNotifyFormSchema),
    defaultValues: {
      includePeopleToNotify: false,
      people: [
        {
          title: "",
          firstName: "",
          lastName: "",
          address: {
            line1: "",
            line2: "",
            town: "",
            county: "",
            postcode: "",
          },
        },
      ],
    },
  })

  const { fields, append, remove } = useFieldArray({
    name: "people",
    control: form.control,
  })

  function onSubmit(data: PeopleToNotifyForm) {
    // In a real application, you would save this data to your backend
    console.log(data)
    router.push(`/lpa/${params.type}/certificate-provider`)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">People to Notify</h1>
        <p className="mt-2 text-gray-600">You can choose up to 5 people to be notified when your LPA is registered</p>
      </div>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>People to notify are optional</AlertTitle>
        <AlertDescription>
          You don't have to include 'people to notify', but they provide additional security for your LPA. They can
          raise concerns about the LPA before it's registered.
        </AlertDescription>
      </Alert>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Do you want to include people to notify?</CardTitle>
              <CardDescription>
                These people will be notified when your LPA is registered and can raise concerns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="includePeopleToNotify"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={(checked) => {
                          field.onChange(checked)
                          setIncludePeople(!!checked)
                        }}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Yes, I want to include people to notify</FormLabel>
                      <FormDescription>
                        You can add up to 5 people who will be notified when your LPA is registered
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {includePeople && (
            <>
              {fields.map((field, index) => (
                <Card key={field.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Person to Notify {index + 1}</CardTitle>
                        <CardDescription>Enter the details of the person you want to notify</CardDescription>
                      </div>
                      {index > 0 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:text-red-700"
                          onClick={() => remove(index)}
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Remove
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-3">
                      <FormField
                        control={form.control}
                        name={`people.${index}.title`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Title</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a title" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="mr">Mr</SelectItem>
                                <SelectItem value="mrs">Mrs</SelectItem>
                                <SelectItem value="miss">Miss</SelectItem>
                                <SelectItem value="ms">Ms</SelectItem>
                                <SelectItem value="dr">Dr</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`people.${index}.firstName`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter first name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name={`people.${index}.lastName`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter last name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="mt-6 space-y-4">
                      <h3 className="font-medium text-gray-900">Address</h3>

                      <div className="grid gap-4">
                        <FormField
                          control={form.control}
                          name={`people.${index}.address.line1`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Address line 1</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter street address" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name={`people.${index}.address.line2`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Address line 2</FormLabel>
                              <FormControl>
                                <Input placeholder="Apartment, suite, etc. (optional)" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid gap-4 md:grid-cols-3">
                          <FormField
                            control={form.control}
                            name={`people.${index}.address.town`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Town/City</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter town or city" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`people.${index}.address.county`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>County</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter county (optional)" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name={`people.${index}.address.postcode`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Postcode</FormLabel>
                                <FormControl>
                                  <Input placeholder="Enter postcode" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {fields.length < 5 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="mt-2"
                  onClick={() =>
                    append({
                      title: "",
                      firstName: "",
                      lastName: "",
                      address: {
                        line1: "",
                        line2: "",
                        town: "",
                        county: "",
                        postcode: "",
                      },
                    })
                  }
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Another Person to Notify
                </Button>
              )}
            </>
          )}

          <div className="flex justify-between">
            <Button type="button" variant="outline" onClick={() => router.push(`/lpa/${params.type}/decisions`)}>
              Previous
            </Button>
            <Button type="submit">
              Continue
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </form>
      </Form>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-medium text-blue-800">About People to Notify</h3>
        <div className="mt-2 text-sm text-blue-700">
          <p className="mb-2">People to notify:</p>
          <ul className="list-disc pl-4 space-y-1">
            <li>Are informed when the LPA is registered with the Office of the Public Guardian</li>
            <li>Can raise concerns about the LPA if they think you're being pressured or there's fraud</li>
            <li>Cannot be the same people as your attorneys or replacement attorneys</li>
            <li>Don't have any power to make decisions for you</li>
            <li>Are optional - you don't have to include any if you don't want to</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

