"use client"

import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ArrowRight, AlertTriangle, Info } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

const certificateProviderFormSchema = z.object({
  certificateProviderType: z.enum(["professional", "known"], {
    required_error: "Please select a certificate provider type",
  }),
  title: z.string({
    required_error: "Please select a title",
  }),
  firstName: z.string().min(2, {
    message: "First name must be at least 2 characters.",
  }),
  lastName: z.string().min(2, {
    message: "Last name must be at least 2 characters.",
  }),
  profession: z.string().optional(),
  yearsKnown: z.string().optional(),
  email: z.string().email({
    message: "Please enter a valid email address",
  }),
  phone: z.string().min(10, {
    message: "Please enter a valid phone number",
  }),
  address: z.object({
    line1: z.string().min(1, "Address line 1 is required"),
    line2: z.string().optional(),
    town: z.string().min(1, "Town/City is required"),
    county: z.string().optional(),
    postcode: z.string().min(5, "Please enter a valid postcode"),
  }),
})

type CertificateProviderForm = z.infer<typeof certificateProviderFormSchema>

export default function CertificateProviderPage({ params }: { params: { type: string } }) {
  const router = useRouter()

  const form = useForm<CertificateProviderForm>({
    resolver: zodResolver(certificateProviderFormSchema),
    defaultValues: {
      address: {
        line1: "",
        line2: "",
        town: "",
        county: "",
        postcode: "",
      },
    },
  })

  const certificateProviderType = form.watch("certificateProviderType")

  function onSubmit(data: CertificateProviderForm) {
    // In a real application, you would save this data to your backend
    console.log(data)
    router.push(`/lpa/${params.type}/fees`)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Certificate Provider</h1>
        <p className="mt-2 text-gray-600">
          Your certificate provider confirms you understand the LPA and are not being pressured
        </p>
      </div>

      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Certificate provider is required</AlertTitle>
        <AlertDescription>
          Every LPA must have a certificate provider. They confirm you understand what you're doing and aren't being
          pressured.
        </AlertDescription>
      </Alert>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Certificate Provider Type</CardTitle>
              <CardDescription>Choose what type of certificate provider you want to use</CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="certificateProviderType"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-start space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="professional" />
                          </FormControl>
                          <div className="space-y-1">
                            <FormLabel className="font-medium">Professional certificate provider</FormLabel>
                            <FormDescription>
                              Someone with relevant professional skills, like a doctor, lawyer, or social worker
                            </FormDescription>
                          </div>
                        </FormItem>
                        <FormItem className="flex items-start space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="known" />
                          </FormControl>
                          <div className="space-y-1">
                            <FormLabel className="font-medium">Someone who has known you for 2+ years</FormLabel>
                            <FormDescription>
                              A friend, neighbor, colleague or someone else who has known you well for at least 2 years
                            </FormDescription>
                          </div>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Certificate Provider Details</CardTitle>
              <CardDescription>Enter the details of your certificate provider</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a title" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="mr">Mr</SelectItem>
                          <SelectItem value="mrs">Mrs</SelectItem>
                          <SelectItem value="miss">Miss</SelectItem>
                          <SelectItem value="ms">Ms</SelectItem>
                          <SelectItem value="dr">Dr</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter first name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter last name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {certificateProviderType === "professional" && (
                  <FormField
                    control={form.control}
                    name="profession"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Profession</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Doctor, Solicitor" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {certificateProviderType === "known" && (
                  <FormField
                    control={form.control}
                    name="yearsKnown"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Years known</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. 5" {...field} />
                        </FormControl>
                        <FormDescription>Must be at least 2 years</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email address</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="Enter email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone number</FormLabel>
                      <FormControl>
                        <Input type="tel" placeholder="Enter phone number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="mt-6 space-y-4">
                <h3 className="font-medium text-gray-900">Address</h3>

                <div className="grid gap-4">
                  <FormField
                    control={form.control}
                    name="address.line1"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Address line 1</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter street address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="address.line2"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Address line 2</FormLabel>
                        <FormControl>
                          <Input placeholder="Apartment, suite, etc. (optional)" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid gap-4 md:grid-cols-3">
                    <FormField
                      control={form.control}
                      name="address.town"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Town/City</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter town or city" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="address.county"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>County</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter county (optional)" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="address.postcode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Postcode</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter postcode" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-between">
            <Button type="button" variant="outline" onClick={() => router.push(`/lpa/${params.type}/people-to-notify`)}>
              Previous
            </Button>
            <Button type="submit">
              Continue
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </form>
      </Form>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Who can be a certificate provider?</AlertTitle>
        <AlertDescription>
          <p className="mb-2">Your certificate provider must be 18 or over and either:</p>
          <ul className="list-disc pl-4 space-y-1">
            <li>Someone with relevant professional skills (like a doctor, lawyer, or social worker)</li>
            <li>Someone who has known you well for at least 2 years</li>
          </ul>
          <p className="mt-2">They cannot be:</p>
          <ul className="list-disc pl-4 space-y-1">
            <li>Any of your attorneys or replacement attorneys</li>
            <li>A member of your family or your attorneys' families</li>
            <li>An unmarried partner of yours or of any of your attorneys</li>
            <li>Your business partner or an attorney's business partner</li>
            <li>Your employee or an attorney's employee</li>
          </ul>
        </AlertDescription>
      </Alert>
    </div>
  )
}

