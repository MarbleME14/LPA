import type React from "react"
import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { Stepper, type Step } from "@/components/lpa/stepper"

export const metadata: Metadata = {
  title: "Create an LPA | LPA Online",
  description: "Create your Lasting Power of Attorney online",
}

export default function LPATypeLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: { type: string }
}) {
  if (!["property-and-financial", "health-and-welfare", "both"].includes(params.type)) {
    notFound()
  }

  // Define all steps with default status
  const steps: Step[] = [
    { id: "who", name: "Who", href: `who`, status: "upcoming" },
    { id: "which-documents", name: "Documents", href: `which-documents`, status: "upcoming" },
    { id: "about-you", name: "About You", href: `about-you`, status: "upcoming" },
    { id: "attorneys", name: "Attorneys", href: `attorneys`, status: "upcoming" },
    { id: "decisions", name: "Decisions", href: `decisions`, status: "upcoming" },
    { id: "people-to-notify", name: "People To Notify", href: `people-to-notify`, status: "upcoming" },
    { id: "certificate-provider", name: "Certificate Provider", href: `certificate-provider`, status: "upcoming" },
    { id: "fees", name: "Fees", href: `fees`, status: "upcoming" },
    { id: "review", name: "Review", href: `review`, status: "upcoming" },
  ]

  return (
    <div className="space-y-8">
      <Stepper steps={steps} currentStep="" />
      {children}
    </div>
  )
}

