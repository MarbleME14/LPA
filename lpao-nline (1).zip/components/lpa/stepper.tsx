"use client"

import { usePathname } from "next/navigation"
import { CheckCircle2, Circle } from "lucide-react"
import { cn } from "@/lib/utils"

export type Step = {
  id: string
  name: string
  href: string
  status: "complete" | "current" | "upcoming"
}

interface StepperProps {
  steps: Step[]
  currentStep?: string
}

export function Stepper({ steps: initialSteps }: StepperProps) {
  // Get the current path on the client side
  const pathname = usePathname()
  const currentStepId = pathname.split("/").pop() || "who"

  // Update step statuses based on the current step
  const steps = initialSteps.map((step) => {
    const stepIndex = initialSteps.findIndex((s) => s.id === step.id)
    const currentStepIndex = initialSteps.findIndex((s) => s.id === currentStepId)

    if (step.id === currentStepId) {
      return { ...step, status: "current" as const }
    } else if (stepIndex < currentStepIndex) {
      return { ...step, status: "complete" as const }
    } else {
      return { ...step, status: "upcoming" as const }
    }
  })

  return (
    <nav aria-label="Progress" className="mb-8">
      <ol role="list" className="overflow-x-auto flex space-x-2 md:space-x-8">
        {steps.map((step, stepIdx) => (
          <li key={step.name} className="md:flex-1 min-w-fit">
            <div
              className={cn(
                "group flex flex-col border-l-4 py-2 pl-4 md:border-l-0 md:border-t-4 md:pb-0 md:pl-0 md:pt-4",
                step.status === "complete" ? "border-blue-600" : "border-gray-200",
              )}
            >
              <span className="text-sm font-medium whitespace-nowrap">
                <span className="flex items-center">
                  <span className="flex-shrink-0 mr-2">
                    {step.status === "complete" ? (
                      <CheckCircle2 className="h-5 w-5 text-blue-600" />
                    ) : step.status === "current" ? (
                      <Circle className="h-5 w-5 text-blue-600" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-400" />
                    )}
                  </span>
                  <span
                    className={cn(
                      step.status === "complete"
                        ? "text-blue-600"
                        : step.status === "current"
                          ? "text-blue-600"
                          : "text-gray-500",
                    )}
                  >
                    {step.name}
                  </span>
                </span>
              </span>
            </div>
          </li>
        ))}
      </ol>
    </nav>
  )
}

